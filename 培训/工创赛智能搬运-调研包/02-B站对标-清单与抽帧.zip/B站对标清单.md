# B 站对标清单（44 条白名单 · 22 条已下载）

> 检索 160 条 → 白名单 44 条 → 下载 22 条 ｜ 2026-09-28 ｜ 判读详见《01-判读笔记-B站》

| # | BV | 标题 | 播放 | 时长 | 日期 | 下载 | 链接 |
|---|---|---|---|---|---|---|---|
| 1 | BV1dj411S7vq | 【工创大赛】可能是B站最详细的工创大赛培训教程 ／ 国赛小车设计 全过程教学演示讲解 | 180631 | 0:00 |  | — | https://www.bilibili.com/video/BV1dj411S7vq |
| 2 | BV17e411C7zJ | 【开源】2023年工训大赛（工创赛）国二智能物流搬运小车 初赛现场与本地调试（包含雷达跑图） | 75782 | 0:00 |  | ✅ | https://www.bilibili.com/video/BV17e411C7zJ |
| 3 | BV1wUbPzMEHU | 【已开源】再见了，所有的工创赛。｜2025工创赛智能物流搬运国赛｜初赛三分钟满环 | 45477 | 0:00 |  | ✅ | https://www.bilibili.com/video/BV1wUbPzMEHU |
| 4 | BV1yy8Y6jEmz | 【全网首发】2027工创赛智能搬运小车全套开源！三维图+清单免费领！已验证方案直接抄作业！ | 41727 | 0:00 |  | ✅ | https://www.bilibili.com/video/BV1yy8Y6jEmz |
| 5 | BV1oTFXztEEz | 【工创大赛】如何制作一台智能物流小车—1.机械结构 | 27987 | 0:00 |  | ✅ | https://www.bilibili.com/video/BV1oTFXztEEz |
| 6 | BV12LQ4BmEJS | [开源]25工创智能物流搬运国特（全国第六）省特（江苏省冠）备赛记录 | 22686 | 0:00 |  | ✅ | https://www.bilibili.com/video/BV12LQ4BmEJS |
| 7 | BV1Nzt8zjENi | [开源]2025工训赛智能物流搬运，初赛第八，2分26秒 | 21367 | 0:00 |  | ✅ | https://www.bilibili.com/video/BV1Nzt8zjENi |
| 8 | BV144Li6sEoR | 【工创大赛】2027新能源赛题深度解析 ／ 竟改了这么多？！太阳能与温差小车分家啦！ | 16006 | 0:00 |  | — | https://www.bilibili.com/video/BV144Li6sEoR |
| 9 | BV1o9uvzvEtX | （完全开源）纪念我的智能物流搬运小车～ | 12640 | 0:00 |  | ✅ | https://www.bilibili.com/video/BV1o9uvzvEtX |
| 10 | BV1RRYo6qEj7 | 【开源】工创赛智能物流搬运小车｜方案讲解＋实车演示+控制教程 | 9343 | 0:00 |  | ✅ | https://www.bilibili.com/video/BV1RRYo6qEj7 |
| 11 | BV1hPLt6MEkY | 2027工创赛-夹爪如何设计？核心任务搬运？智能搬运技术分享【合集+高光】 | 8945 | 0:00 |  | ✅ | https://www.bilibili.com/video/BV1hPLt6MEkY |
| 12 | BV14F5m6UEmH | 领琛科技 ／ ⭐工创赛万字赛题解读⭐太阳能&amp;温差·规则变化·避坑指南 | 4523 | 0:00 |  | — | https://www.bilibili.com/video/BV14F5m6UEmH |
| 13 | BV1gTep6iER5 | 【开源机械必看！！！】工创赛智能物流搬运小车底盘设计 | 4460 | 0:00 |  | ✅ | https://www.bilibili.com/video/BV1gTep6iER5 |
| 14 | BV1FEp2zTEHw | 第七讲：物流搬运赛项实践 | 4214 | 0:00 |  | ✅ | https://www.bilibili.com/video/BV1FEp2zTEHw |
| 15 | BV1bM5yzdEMp | 基于STM32单片机的智能物料搬运小车实物设计 | 3981 | 0:00 |  | — | https://www.bilibili.com/video/BV1bM5yzdEMp |
| 16 | BV1qXb36qENY | 【904回放】2027工创赛-全网最新2027工创赛-智能搬运机器人重磅来袭!内含选型设计+从0搭建分享直播回放 | 3702 | 0:00 |  | ✅ | https://www.bilibili.com/video/BV1qXb36qENY |
| 17 | BV1JEQdYfE5L | 【从气急败坏到生无可恋】工训赛新能源赛道-调车实战教学 | 3678 | 0:00 |  | — | https://www.bilibili.com/video/BV1JEQdYfE5L |
| 18 | BV1ztVV6BEXL | 领琛科技 ／ 工创赛电气备赛指南：从硬件到软件一次讲透 | 2613 | 0:00 |  | — | https://www.bilibili.com/video/BV1ztVV6BEXL |
| 19 | BV1iag46aEyt | 27工创赛题交流分享，欢迎大家提问讨论（视频内容为老奶奶说梦话，想到啥说啥） | 1909 | 0:00 |  | — | https://www.bilibili.com/video/BV1iag46aEyt |
| 20 | BV15mhb6QEjs | 工创赛，智能救援，机械方案分享 | 1104 | 0:00 |  | — | https://www.bilibili.com/video/BV15mhb6QEjs |
| 21 | BV1RdPez2EYz | 2026北京市工创大赛-智能物流搬运 | 395 | 0:00 |  | — | https://www.bilibili.com/video/BV1RdPez2EYz |
| 22 | BV1wUhD6hEWa | 工创赛工程实践赛道赛题解析及得分详解 | 273 | 0:00 |  | — | https://www.bilibili.com/video/BV1wUhD6hEWa |
| 23 | BV1qNhJ68Exa | 工创赛培训录屏 | 74 | 0:00 |  | — | https://www.bilibili.com/video/BV1qNhJ68Exa |
| 24 | BV1AHd8YiEp5 | 2025工训赛，智能物流搬运，2分15秒 | 73592 | 0:00 |  | ✅ | https://www.bilibili.com/video/BV1AHd8YiEp5 |
| 25 | BV1vi4veJENj | 致2025工创物流搬运小车，部分代码已开源 | 29189 | 0:00 |  | — | https://www.bilibili.com/video/BV1vi4veJENj |
| 26 | BV16yXhYZEu5 | 工创赛也就那样 | 20200 | 0:00 |  | ✅ | https://www.bilibili.com/video/BV16yXhYZEu5 |
| 27 | BV18N4oz8EnC | ［25工创］玫瑰骑士 并联scara双工作区间 智能物流搬运新思路 | 8837 | 0:00 |  | ✅ | https://www.bilibili.com/video/BV18N4oz8EnC |
| 28 | BV1Vvtw6NEGK | 27工创赛太阳能小车满点/10点调车视频 | 4635 | 0:00 |  | — | https://www.bilibili.com/video/BV1Vvtw6NEGK |
| 29 | BV16L2CYyEtM | 学生及指导教师报名-2024北京市工创大赛 | 4300 | 0:00 |  | — | https://www.bilibili.com/video/BV16L2CYyEtM |
| 30 | BV1rCMf64EDB | 2026广东省工训赛智能物流省冠实录 | 3829 | 0:00 |  | ✅ | https://www.bilibili.com/video/BV1rCMf64EDB |
| 31 | BV18xJkzNETh | 工创赛小车 | 3813 | 0:00 |  | — | https://www.bilibili.com/video/BV18xJkzNETh |
| 32 | BV1qTsEzoERB | 2025Robocup物流搬运国赛 黑武士 | 2408 | 0:00 |  | — | https://www.bilibili.com/video/BV1qTsEzoERB |
| 33 | BV1ANht6aEgo | 工创赛智能分拣全流程运行展示 | 1857 | 0:00 |  | — | https://www.bilibili.com/video/BV1ANht6aEgo |
| 34 | BV17ee36EEGB | 工程训练 工创赛 智能＋赛道 物流搬运赛项 智能物流搬运机器人 避障案例分享 | 1568 | 0:00 |  | ✅ | https://www.bilibili.com/video/BV17ee36EEGB |
| 35 | BV133w7zdE1v | 介绍非法组件：搬运机器人 | 1281 | 0:00 |  | ✅ | https://www.bilibili.com/video/BV133w7zdE1v |
| 36 | BV19Kei6CETT | 2027工创赛智能搬运赛道 | 862 | 0:00 |  | ✅ | https://www.bilibili.com/video/BV19Kei6CETT |
| 37 | BV1CShE66EEd | 工创赛智能搬运全流程运行展示 | 644 | 0:00 |  | ✅ | https://www.bilibili.com/video/BV1CShE66EEd |
| 38 | BV1cogwzJETL | 智能物流搬运起重机 | 540 | 0:00 |  | — | https://www.bilibili.com/video/BV1cogwzJETL |
| 39 | BV1VcH2zRET3 | 算法赛：无人车物流搬运挑战赛 | 494 | 0:00 |  | — | https://www.bilibili.com/video/BV1VcH2zRET3 |
| 40 | BV1BDhW65Ee2 | ✨2027工创赛｜太阳能小车实测运行！ | 482 | 0:00 |  | — | https://www.bilibili.com/video/BV1BDhW65Ee2 |
| 41 | BV184hv68Eam | 你的智能搬运工上线啦 | 9 | 0:00 |  | — | https://www.bilibili.com/video/BV184hv68Eam |
| 42 | BV172XJYZEYx | 千 万 不 要 让RM队友设计物流小车 | 21482 | 0:00 |  | — | https://www.bilibili.com/video/BV172XJYZEYx |
| 43 | BV17he36nE2s | 工创赛智能＋赛道，智能物流搬运机器人避障策论 | 625 | 0:00 |  | — | https://www.bilibili.com/video/BV17he36nE2s |
| 44 | BV1Coh16SEvD | 智能搬运机械臂、爪 2027工创智能搬运 | 120 | 0:00 |  | — | https://www.bilibili.com/video/BV1Coh16SEvD |

> 说明：完整 160 条原始检索结果见 bili_raw.json；本清单为黑/白名单过滤后的候选。
