#ifndef _HEAD_H 
    #define _HEAD_H

    #include <Arduino.h>

    // 热点名前缀
    #define HOSTNAME "RobotS3_"
    //mqtt 账号和密码
    #define MqttAccount "esp32s3"
    #define MqttPwd "123321"

    #define CONFIG_ESPNOW false     // 是否配有esp-now中继器
    #define CONFIG_GPS  true        // 是否配有GPS模块
// gps模块数据格式示例：
// $BDZDA,081920.000,08,05,2025,00,00*4D
// $GPTXT,01,01,01,ANTENNA OK*35
// $BDGGA,081921.000,3027.76015,N,11427.12586,E,1,11,1.0,81.9,M,-13.9,M,,*53
// $BDGLL,3027.76015,N,11427.12586,E,081921.000,A,A*41
// $BDGSA,A,3,07,08,13,19,20,22,29,35,38,40,44,,2.0,1.0,1.7,4*3B
// $BDRMC,081921.000,A,3027.76015,N,11427.12586,E,0.00,0.00,080525,,,A,V*06
// $BDVTG,0.00,T,,M,0.00,N,0.00,K,A*2C

    typedef struct
    {
        unsigned char commandID;    // 命令: 0:断开 1:遥控数据 2：app和esp匹配
        unsigned char sideCmd;      // 数据源，0：手柄 1：手机端app，2：掌机端app 3：中继器转发的手柄数据
    } struct_message_head;
    
    typedef struct
    {
        unsigned char commandID;    
        unsigned char sideCmd;      
        unsigned char lx;           // 手柄左摇杆x轴数据，范围0~200, 100表示居中
        unsigned char ly;           // 手柄左摇杆y轴数据，范围0~200, 100表示居中
        unsigned char rx;
        unsigned char ry;
        unsigned char buttons[2];   // 可表达16个按键状态，按下为1，未按下为0
        unsigned char speed;
        unsigned char model;
    } struct_message_JOYData;

#endif