﻿micro-ros测试

ubuntu步骤如下

===========================================================================================安装ros2
wget http://fishros.com/install -O fishros && bash fishros

===========================================================================================配置代理
mkdir -p ~/microros_ws/src
cd ~/microros_ws
#下载代理源码
git clone https://github.com/micro-ROS/micro-ROS-Agent.git -b jazzy
git clone https://github.com/micro-ROS/micro_ros_msgs.git -b jazzy
#构建代理
S colcon build

======================================================================================安装测试用的键盘控制包
# 安装键盘控制包
sudo apt update
sudo apt install ros-jazzy-teleop-twist-keyboard
# 确认安装成功
ros2 pkg list | grep teleop

====================================================================================创建心跳监听节点
mkdir -p ~/ros2_ws/src
cd ~/ros2_ws/src
touch heartbeat_listener.py
chmod +x heartbeat_listener.py
代码详见esp32的项目文件下


====================================================================================开始测试
#1.启动代理
cd ~/microros_ws
source install/setup.bash
ros2 run micro_ros_agent micro_ros_agent udp4 --port 8888
#2.另开一个终端 启动心跳监听节点
cd ~/ros2_ws/src
python3 heartbeat_listener.py
#3.再开一个终端 启动键盘控制节点
ros2 run teleop_twist_keyboard teleop_twist_keyboard
#4.esp32 上电后查看串口日志

====================================================================================启动脚本优化启动
touch start_car_control.sh
nano start_car_control.sh  文件详见
chmod +x start_car_control.sh
./start_car_control.sh

====================================================================================故障排除相关命令
# 检查话题是否存在
ros2 topic list | grep heartbeat
# 直接 echo 话题内容
ros2 topic echo /esp32/heartbeat

# 检查 /cmd_vel 话题是否被正确发布
ros2 topic echo /cmd_vel --once
# 手动发布测试消息
ros2 topic pub /cmd_vel geometry_msgs/msg/Twist "{linear: {x: 0.5, y: 0.0, z: 0.0}, angular: {x: 0.0, y: 0.0, z: 0.0}}"
