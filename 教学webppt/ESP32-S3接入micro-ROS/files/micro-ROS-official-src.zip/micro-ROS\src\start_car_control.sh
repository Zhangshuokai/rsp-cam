﻿#!/bin/bash

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}=================================${NC}"
echo -e "${GREEN}    ESP32 小车控制系统启动      ${NC}"
echo -e "${GREEN}=================================${NC}"

# 检查代理是否已经在运行
if pgrep -f "micro_ros_agent" > /dev/null; then
    echo -e "${YELLOW}⚠️ micro-ROS代理已经在运行${NC}"
else
    echo -e "${GREEN}启动 micro-ROS 代理...${NC}"
    # 在新终端中启动代理
    gnome-terminal -- bash -c "source ~/ros2_ws/install/setup.bash; ros2 run micro_ros_agent micro_ros_agent udp4 --port 8888; exec bash" 2>/dev/null || \
    xterm -e "source ~/microros_ws/install/setup.bash; ros2 run micro_ros_agent micro_ros_agent udp4 --port 8888" &
    sleep 2
fi

echo -e "${GREEN}启动心跳监听节点...${NC}"
# 在新终端中启动心跳监听
gnome-terminal -- bash -c "cd ~/ros2_ws/src; python3 heartbeat_listener.py; exec bash" 2>/dev/null || \
xterm -e "cd ~/ros2_ws/src; python3 heartbeat_listener.py" &
sleep 1

echo -e "${GREEN}启动键盘控制节点...${NC}"
# 在当前终端启动键盘控制（或者新终端）
gnome-terminal -- bash -c "ros2 run teleop_twist_keyboard teleop_twist_keyboard; exec bash" 2>/dev/null || \
xterm -e "ros2 run teleop_twist_keyboard teleop_twist_keyboard" &

echo -e "${GREEN}所有节点已启动！${NC}"
echo -e "${YELLOW}控制说明：${NC}"
echo -e "  i - 前进"
echo -e "  k - 停止"
echo -e "  j - 左转"
echo -e "  l - 右转"
echo -e "  , - 后退"
echo -e "  q/z - 加速/减速"