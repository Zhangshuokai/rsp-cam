/**奇果派示例代码，基于ESP32开发板和micro-ROS库。
  * 该代码实现了一个简单的ROS2节点：
  * 1.订阅/cmd_vel话题上的Twist消息；
  * 2.并发布心跳消息到/esp32/heartbeat话题。
 */
#include <Arduino.h>
#include <micro_ros_platformio.h>    // 包含用于 ESP32 的 micro-ROS PlatformIO 库
#include <WiFi.h>                    
#include <rcl/rcl.h>                 // 包含 ROS 客户端库 (RCL)
#include <rclc/rclc.h>               // 包含用于 C 的 ROS 客户端库 (RCLC)
#include <rclc/executor.h>           // 包含 RCLC 执行程序库，用于执行订阅和发布
#include <geometry_msgs/msg/twist.h> // 包含 ROS2 geometry_msgs/Twist 消息类型
#include <std_msgs/msg/int32.h>     // 包含 ROS2 std_msgs/Int32 消息类型

// 配置参数
#define WIFI_SSID "Bear"            // wifi名
#define WIFI_PASSWORD "1234567890"  // wifi密码
#define AGENT_IP "192.168.119.127"  // ros2所在服务器的ip
#define AGENT_PORT 8888

rclc_executor_t executor;           // RCLC 执行程序对象，用于处理订阅和发布
rclc_support_t support;             // RCLC 支持对象，用于管理 ROS2 上下文和节点
rcl_allocator_t allocator;          // RCL 分配器对象，用于分配内存
rcl_node_t node;                    // RCL 节点对象，用于此基于 ESP32 的机器人小车
rcl_subscription_t subscriber;      // RCL 订阅对象，用于订阅 ROS2 消息
rcl_publisher_t heartbeat_publisher;  // 心跳发布者
geometry_msgs__msg__Twist sub_msg;  // ROS2 geometry_msgs/Twist 消息对象
std_msgs__msg__Int32 pub_msg;       // 心跳消息

// 状态标志
bool micro_ros_connected = false;
int heartbeat_count = 0;

// 函数声明
bool create_entities();
void destroy_entities();
void twist_callback(const void *msg_in);

// 回调函数，当接收到新的 Twist 消息时会被调用
void twist_callback(const void *msg_in)
{
  const geometry_msgs__msg__Twist *twist_msg = (const geometry_msgs__msg__Twist *)msg_in;
  float linear_x = twist_msg->linear.x;   // 获取 Twist 消息的线性 x 分量
  float linear_y = twist_msg->linear.y;
  float angular_z = twist_msg->angular.z; // 获取 Twist 消息的角度 z 分量
  Serial.printf("Received Twist message: xyz = %f,%f,%f\n", linear_x,linear_y, angular_z);
  
}

// 创建 micro-ROS 实体
bool create_entities()
{
  Serial.println("[ROS] Creating entities...");
  
  allocator = rcl_get_default_allocator();
  
  // 初始化支持结构
  rcl_ret_t ret = rclc_support_init(&support, 0, NULL, &allocator);
  if (ret != RCL_RET_OK) {
    Serial.println("[ROS] Failed to init support");
    return false;
  }
  
  // 创建节点
  ret = rclc_node_init_default(&node, "esp32_car", "", &support);
  if (ret != RCL_RET_OK) {
    Serial.println("[ROS] Failed to init node");
    return false;
  }
  
  // 创建订阅者
  ret = rclc_subscription_init_default(
      &subscriber,
      &node,
      ROSIDL_GET_MSG_TYPE_SUPPORT(geometry_msgs, msg, Twist),
      "/cmd_vel");
  if (ret != RCL_RET_OK) {
    Serial.println("[ROS] Failed to init subscriber");
    return false;
  }
  
  // 创建心跳发布者
  ret = rclc_publisher_init_default(
      &heartbeat_publisher,
      &node,
      ROSIDL_GET_MSG_TYPE_SUPPORT(std_msgs, msg, Int32),
      "/esp32/heartbeat");
  if (ret != RCL_RET_OK) {
    Serial.println("[ROS] Failed to init publisher");
    return false;
  }
  
  // 初始化执行器
  ret = rclc_executor_init(&executor, &support.context, 2, &allocator);
  if (ret != RCL_RET_OK) {
    Serial.println("[ROS] Failed to init executor");
    return false;
  }
  
  // 添加订阅者到执行器
  ret = rclc_executor_add_subscription(&executor, &subscriber, &sub_msg, 
                                       &twist_callback, ON_NEW_DATA);
  if (ret != RCL_RET_OK) {
    Serial.println("[ROS] Failed to add subscription");
    return false;
  }
  
  Serial.println("[ROS] Entities created successfully");
  return true;
}

// 销毁 micro-ROS 实体
void destroy_entities()
{
  Serial.println("[ROS] Destroying entities...");
  rcl_subscription_fini(&subscriber, &node);
  rcl_publisher_fini(&heartbeat_publisher, &node);
  rcl_node_fini(&node);
  rclc_support_fini(&support);
  micro_ros_connected = false;
}

// 等待 WiFi 连接
bool wait_for_wifi(unsigned long timeout_ms)
{
  Serial.print("[WiFi] Connecting to ");
  Serial.println(WIFI_SSID);
  
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
    if (millis() - start > timeout_ms) {
      Serial.println("\n[WiFi] Connection timeout!");
      return false;
    }
  }
  
  Serial.println("\n[WiFi] Connected!");
  Serial.print("[WiFi] IP address: ");
  Serial.println(WiFi.localIP());
  return true;
}

// 这个函数是一个后台任务，负责设置和处理与 micro-ROS 代理的通信。
void microros_task(void *param)
{
  // 1. 先连接 WiFi
  if (!wait_for_wifi(30000)) {
    Serial.println("[ERROR] WiFi connection failed, restarting...");
    ESP.restart();
  }
  
  // 2. 设置 micro-ROS 传输
  IPAddress agent_ip;
  agent_ip.fromString(AGENT_IP);
  set_microros_wifi_transports(WIFI_SSID, WIFI_PASSWORD, agent_ip, AGENT_PORT);
  delay(1000);  // 给传输层一点时间
  
  // 3. 连接和主循环
  unsigned long last_heartbeat_time = 0;
  const unsigned long heartbeat_interval = 1000;  // 1秒发布一次心跳
  
  while (true)
  {
    // 检查连接状态
    if (!micro_ros_connected) {
      Serial.println("[ROS] Attempting to connect to agent...");
      
      // 尝试连接代理
      if (rmw_uros_ping_agent(100, 1) == RMW_RET_OK) {
        Serial.println("[ROS] Agent found, creating entities...");
        
        if (create_entities()) {
          micro_ros_connected = true;
          heartbeat_count = 0;
          Serial.println("[ROS] Connected and ready!");
        }
      } else {
        Serial.println("[ROS] Agent not available, retrying in 1s...");
        delay(1000);
        continue;
      }
    }
    
    // 已连接状态
    if (micro_ros_connected) {
      // 执行 spin（处理订阅消息）
      rcl_ret_t ret = rclc_executor_spin_some(&executor, RCL_MS_TO_NS(100));
      
      // 检查连接是否丢失
      if (ret != RCL_RET_OK || rmw_uros_ping_agent(100, 3) != RMW_RET_OK) {
        Serial.println("[ROS] Connection lost!");
        destroy_entities();
        continue;
      }
      
      // 定期发布心跳
      if (millis() - last_heartbeat_time > heartbeat_interval) {
        pub_msg.data = heartbeat_count++;
        rcl_ret_t pub_ret = rcl_publish(&heartbeat_publisher, &pub_msg, NULL);
        
        if (pub_ret == RCL_RET_OK) {
          Serial.printf("[ROS] Heartbeat sent: %d\n", pub_msg.data);
        }
        
        last_heartbeat_time = millis();
      }
      
      delay(10);  
    }
  }
}

void setup()
{
  Serial.begin(115200); 
  xTaskCreatePinnedToCore(microros_task, "microros_task", 10240, NULL, 1, NULL, 0);
  Serial.println("setup done");
}

void loop()
{
  // 这里可以写其它逻辑，例如处理传感器数据、控制小车等。
}