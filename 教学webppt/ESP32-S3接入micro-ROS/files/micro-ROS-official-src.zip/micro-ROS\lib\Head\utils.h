#ifndef _utils_H 
    #define _utils_H
#include <Arduino.h>
#include <ArduinoOTA.h>
#include "config.h"

#define ANALOG_RETRY_COUNT 5
#define PIN_PWR_ADC 2

// 定义电阻值（单位：欧姆）
const float R1 = 10000.0;  // 10k欧姆
const float R2 = 1000.0;   // 1k欧姆
const float V_ref = 3.3;  // ESP32 ADC参考电压，单位伏特

// 计算电池电量百分比，返回0-100之间的值
int getBatteryRatio()
{
  uint16_t v;
  uint32_t sum = 0;
  uint16_t values[ANALOG_RETRY_COUNT];

  for (uint8_t i = 0; i < ANALOG_RETRY_COUNT; i++)
  {
    v = analogRead(PIN_PWR_ADC);
    values[i] = v;
    sum += v;
  }

  uint16_t avg = sum / ANALOG_RETRY_COUNT;
  uint8_t cnt = ANALOG_RETRY_COUNT;
  for (uint8_t i = 0; i < ANALOG_RETRY_COUNT; i++)
  {
    v = values[i];
    if (abs(v - avg) > 100)
    {
      sum -= v;
      cnt--;
    }
  }

  int ADC_value = (cnt > 0) ? (sum / cnt) : 0;  // 读取ADC值
  float V_adc = (ADC_value / 4095.0) * V_ref;   // 将ADC值转换为电压值
  float voltage = ((R1 + R2) / R2) * V_adc;     // 使用公式计算电池电压值
  int standardVoltage = 12;   // 标准电压值，单位伏特
  float minVoltage = standardVoltage *0.83, maxVoltage = standardVoltage;
  
  
  if (voltage < minVoltage){
    Serial.printf("电池电压过低：%.2fV\n", voltage);
    return 0;
  } 
  if (voltage > maxVoltage){
    Serial.printf("电池满电：%.2fV\n", voltage);
    return 100;
  } 

  float ratio = (voltage - minVoltage) / (maxVoltage - minVoltage);
  int rate = static_cast<uint8_t>(roundf(ratio * 100.0f));
  Serial.printf("电池电压：%.2fV, 百分比：%d\n", voltage, rate);
  return rate;
}

bool otaIsRunning = false; // OTA是否正在进行
void initOTA()
{
  ArduinoOTA
  .onStart([]()
              {
  String type;
  if (ArduinoOTA.getCommand() == U_FLASH)
      type = "sketch";
  else // U_SPIFFS
      type = "filesystem";
  Serial.println("Start updating " + type); })
  .onEnd([]()
          { otaIsRunning = true; Serial.println("\nEnd"); })
  .onProgress([](unsigned int progress, unsigned int total)
              { Serial.printf("Progress: %u%%\r", (progress / (total / 100))); })
  .onError([](ota_error_t error)
              {
              Serial.printf("Error[%u]: ", error);
              if (error == OTA_AUTH_ERROR) Serial.println("Auth Failed");
              else if (error == OTA_BEGIN_ERROR) Serial.println("Begin Failed");
              else if (error == OTA_CONNECT_ERROR) Serial.println("Connect Failed");
              else if (error == OTA_RECEIVE_ERROR) Serial.println("Receive Failed");
              else if (error == OTA_END_ERROR) Serial.println("End Failed"); });
  ArduinoOTA.begin();
}

bool connectWifi(const char* ssid, const char* pwd)
{
  WiFi.begin(ssid, pwd);
  int retry_count = 0;
  while (retry_count < 8)
  {
    delay(500);
    Serial.print(".");
    retry_count++;
    if (WiFi.status() == WL_CONNECTED) 
    {
      // Serial.printf("wifi已连接: ip=%s, mac=%s\n", WiFi.localIP().toString(), WiFi.macAddress().c_str());
      return true; 
    }
  }
  return WiFi.status() == WL_CONNECTED;
}
#endif