/**
奇果派Esp32-S3电机驱动板示例代码：连接ps2手柄
1.准备ps2手柄和接收器
2.准备转接板，接收器插转接板上
3.准备母对母杜邦线6条,接线如下：
vcc：3.3V
GND:GND
CLK:42
CMD:41
ATT:40
DAT:39
实现功能：获取ps2遥控器的操控数据
*/
#include "PS2X_lib.h"
PS2X ps2x;

void setup() 
{
  Serial.begin(115200);
  int error = 0;
  error = ps2x.config_gamepad(42,41,40,39, true, true);   //可根据实际情况调整
  Serial.println("setup");
}

void loop() 
{
  ps2x.read_gamepad(false, 0);
  if (ps2x.Button(PSB_PAD_UP)) {
    Serial.println("PSB_PAD_UP");
  }

  if (ps2x.Analog(PSS_LY) < 125) {
    Serial.printf("PSS_LY:%d\n", ps2x.Analog(PSS_LY));
  }else if (ps2x.Analog(PSS_LY) > 130) {
    Serial.printf("PSS_LY:%d\n", ps2x.Analog(PSS_LY));
  }

  if (ps2x.Analog(PSS_LX) < 125) {
    Serial.printf("PSS_LX:%d\n", ps2x.Analog(PSS_LY));
  }else if (ps2x.Analog(PSS_LX) > 130) {
    Serial.printf("PSS_LX:%d\n", ps2x.Analog(PSS_LY));
  }

  if (ps2x.Analog(PSS_RY) < 125) {
    Serial.printf("PSS_RY:%d\n", ps2x.Analog(PSS_LY));
  }else if (ps2x.Analog(PSS_RY) > 130) {
    Serial.printf("PSS_RY:%d\n", ps2x.Analog(PSS_LY));
  }

  if (ps2x.Analog(PSS_RX) < 125) {
    Serial.printf("PSS_RX:%d\n", ps2x.Analog(PSS_LY));
  }else if (ps2x.Analog(PSS_RX) > 130) {
    Serial.printf("PSS_RX:%d\n", ps2x.Analog(PSS_LY));
  }

  delay(5);
}
