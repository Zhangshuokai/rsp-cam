/**
奇果派Esp32-S3电机驱动板示例代码：oled显示屏示例
1.0.96寸i2c接口的oled屏，插在开发板的oled接口上
2.请导入库 Adafruit SSD1306
实现oled屏幕显示及刷新
*/

#include <Arduino.h>
#include <Adafruit_GFX.h>            // led 加载Adafruit_GFX库
#include <Adafruit_SSD1306.h>        // led 加载Adafruit_SSD1306库

Adafruit_SSD1306 display;         //led显示屏

void setup() 
{
  Serial.begin(115200); 
  
  // OLED初始化
  display = Adafruit_SSD1306(128, 64, &Wire);
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C); // 设置OLED的I2C地址
  display.clearDisplay();                    // 清空屏幕
  display.setTextSize(2);                    // 设置字体大小
  display.setCursor(0, 0);                   // 设置开始显示文字的坐标
  display.setTextColor(SSD1306_WHITE);       // 设置字体颜色
  display.println("setup");   
  display.display();
  delay(1000);
}

void loop() 
{
  display.clearDisplay();  
  display.setCursor(0, 0);  
  display.println("Hello");   
  display.println("Kikupi");   
  display.display();

  delay(1500);

  display.clearDisplay();  
  display.setCursor(0, 0);  
  display.println("I love you");   
  display.display();
  delay(1500);
}
