/**
奇果派Esp32-S3 物联网示例代码：mqtt遥控
1.修改唯一通讯标识 abc123和控制端一致
2.录入wifi名称和密码
3.浏览器打 http://rc.7gp.cn/   输入唯一通讯标识
实现功能：订阅控制端的消息
*/

#include <Arduino.h>
#include <WiFi.h>
#include "WFJoystick.h"

//参数：           服务器地址    端口    账号      密码        唯一通讯标识
WFJoystick wfJoy("mqtt.7gp.cn", 1883, "mixly", "mixly123", "abc123");   

void setup() 
{
  Serial.begin(115200);
  delay(50);
  WiFi.begin("Niangao", "12345ssdlh");       //修改为当前可用的wifi名和密码 
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.print("Local IP:");
  Serial.println(WiFi.localIP());

  wfJoy.begin();
}

void loop() 
{
  wfJoy.readCommand();
  if (wfJoy.Button(BTN_A)) {
    Serial.println("Btn_A");

  }
  if (wfJoy.Analog(VJ_LY) > 128) {
    Serial.println("down");

  } else if (wfJoy.Analog(VJ_LY) < 127) {
    Serial.println("up");
  }
}

